import { useState, useEffect, useRef } from "react";
import { MessageCircle, X, Send, User, Bot, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";

type Message = {
  role: "user" | "bot";
  content: string;
};

export function ChatWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: "bot", content: "Hi! Welcome to Floral World. How can I help you pick the perfect flowers today?" }
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo(0, scrollRef.current.scrollHeight);
    }
  }, [messages]);

  const handleSend = () => {
    if (!input.trim()) return;

    const userMsg = input.trim();
    setMessages(prev => [...prev, { role: "user", content: userMsg }]);
    setInput("");
    setIsTyping(true);

    // Simulate bot response
    setTimeout(() => {
      let response = "That sounds lovely! Would you like to see our premium rose collections or maybe some mixed seasonal bouquets?";
      
      if (userMsg.toLowerCase().includes("price") || userMsg.toLowerCase().includes("cost")) {
        response = "Our bouquets start from just ₹499! We have options for every budget. What occasion are you shopping for?";
      } else if (userMsg.toLowerCase().includes("delivery")) {
        response = "We offer same-day and midnight delivery across Kolkata! Where would you like the flowers delivered?";
      }

      setMessages(prev => [...prev, { role: "bot", content: response }]);
      setIsTyping(false);
    }, 1000);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {isOpen ? (
        <Card className="w-[350px] sm:w-[400px] shadow-2xl border-primary/20 flex flex-col animate-in slide-in-from-bottom-4 duration-300 h-[500px]">
          <CardHeader className="bg-primary text-white p-4 rounded-t-xl flex flex-row items-center justify-between space-y-0">
            <CardTitle className="text-lg flex items-center gap-2">
              <MessageCircle className="w-5 h-5" />
              Floral Assistant
            </CardTitle>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setIsOpen(false)}
              className="text-white hover:bg-white/20"
            >
              <X className="w-5 h-5" />
            </Button>
          </CardHeader>
          <CardContent className="p-0 flex-grow flex flex-col overflow-hidden bg-secondary/10">
            <ScrollArea className="flex-grow p-4">
              <div className="space-y-4 pr-4">
                {messages.map((m, i) => (
                  <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                    <div className={`flex gap-2 max-w-[80%] ${m.role === "user" ? "flex-row-reverse" : ""}`}>
                      <div className={`w-8 h-8 rounded-full shrink-0 flex items-center justify-center ${m.role === "user" ? "bg-primary text-white" : "bg-white text-primary border border-primary/10"}`}>
                        {m.role === "user" ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                      </div>
                      <div className={`p-3 rounded-2xl text-sm ${m.role === "user" ? "bg-primary text-white rounded-tr-none" : "bg-white text-foreground rounded-tl-none shadow-sm"}`}>
                        {m.content}
                      </div>
                    </div>
                  </div>
                ))}
                {isTyping && (
                  <div className="flex justify-start">
                    <div className="flex gap-2 max-w-[80%]">
                      <div className="w-8 h-8 rounded-full bg-white text-primary border border-primary/10 flex items-center justify-center">
                        <Bot className="w-4 h-4" />
                      </div>
                      <div className="p-3 rounded-2xl bg-white text-foreground rounded-tl-none shadow-sm italic text-xs flex items-center gap-2">
                        <Loader2 className="w-3 h-3 animate-spin" />
                        Typing...
                      </div>
                    </div>
                  </div>
                )}
                <div ref={scrollRef} />
              </div>
            </ScrollArea>
            <div className="p-4 bg-white border-t border-border">
              <form 
                onSubmit={(e) => { e.preventDefault(); handleSend(); }}
                className="flex gap-2"
              >
                <Input 
                  placeholder="Type a message..." 
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  className="rounded-full bg-secondary/30 border-none focus-visible:ring-primary/20"
                />
                <Button type="submit" size="icon" className="rounded-full shrink-0">
                  <Send className="w-4 h-4" />
                </Button>
              </form>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Button 
          onClick={() => setIsOpen(true)}
          className="w-14 h-14 rounded-full shadow-2xl bg-primary hover:bg-primary/90 text-white animate-bounce-slow"
          size="icon"
        >
          <MessageCircle className="w-7 h-7" />
        </Button>
      )}
    </div>
  );
}
