import { Leaf, Clock, Heart } from "lucide-react";

export function AboutSection() {
  return (
    <section id="about" className="py-24 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="relative">
            <div className="absolute -inset-4 bg-secondary/50 rounded-[2.5rem] transform -rotate-3 transition-transform hover:rotate-0 duration-500 z-0"></div>
            {/* Unsplash close up of person holding bouquet */}
            <img
              src="https://images.unsplash.com/photo-1591886960571-74d43a9d4166?q=80&w=1000&auto=format&fit=crop"
              alt="Florist arranging flowers"
              className="relative z-10 rounded-3xl shadow-xl w-full h-[500px] object-cover"
            />
            <div className="absolute -bottom-6 -right-6 bg-white p-6 rounded-2xl shadow-xl z-20 hidden md:block border border-border">
              <p className="text-4xl font-display font-bold text-primary mb-1">10+</p>
              <p className="text-sm font-medium text-foreground/70">Years of bringing<br/>smiles to Kolkata</p>
            </div>
          </div>

          <div className="space-y-8">
            <div>
              <h2 className="text-primary font-medium tracking-wider uppercase text-sm mb-2">About Floral World</h2>
              <h3 className="text-3xl md:text-4xl font-display font-bold text-foreground leading-tight">
                Crafting emotions through elegant floral artistry.
              </h3>
            </div>
            
            <p className="text-lg text-foreground/70 leading-relaxed text-balance">
              Located in the heart of Bhowanipore, Floral World has been a trusted name in Kolkata for fresh, quality flowers and exquisite arrangements. We believe that every bouquet tells a story, and we take pride in helping you share yours.
            </p>

            <div className="space-y-6 pt-4">
              <div className="flex gap-4">
                <div className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center shrink-0">
                  <Leaf className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h4 className="text-xl font-bold text-foreground mb-1">Fresh & Premium Quality</h4>
                  <p className="text-foreground/70">We source only the freshest blooms daily to ensure your arrangements last longer and look stunning.</p>
                </div>
              </div>
              
              <div className="flex gap-4">
                <div className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center shrink-0">
                  <Heart className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h4 className="text-xl font-bold text-foreground mb-1">Elegant Arrangements</h4>
                  <p className="text-foreground/70">Our experienced florists craft each bouquet with love, precision, and an eye for modern design.</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center shrink-0">
                  <Clock className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h4 className="text-xl font-bold text-foreground mb-1">Reliable Delivery</h4>
                  <p className="text-foreground/70">From surprising someone at midnight to guaranteed same-day delivery, we ensure your flowers arrive right on time.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
