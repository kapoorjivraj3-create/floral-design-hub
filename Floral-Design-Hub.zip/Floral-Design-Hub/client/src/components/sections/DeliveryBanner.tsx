import { Truck, Moon, CalendarCheck } from "lucide-react";

export function DeliveryBanner() {
  return (
    <section className="py-12 bg-primary relative overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute top-0 left-0 w-64 h-64 bg-white/10 rounded-full mix-blend-overlay blur-3xl -translate-x-1/2 -translate-y-1/2"></div>
      <div className="absolute bottom-0 right-0 w-64 h-64 bg-white/10 rounded-full mix-blend-overlay blur-3xl translate-x-1/2 translate-y-1/2"></div>
      
      <div className="container relative z-10 mx-auto px-4 md:px-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8 text-white">
          <div className="text-center md:text-left">
            <h3 className="text-2xl md:text-3xl font-display font-bold mb-2">Need it delivered today?</h3>
            <p className="text-white/80 max-w-md">We offer premium delivery services across Kolkata and surrounding areas to ensure your surprise is perfect.</p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-6 md:gap-12">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center backdrop-blur-sm">
                <Truck className="w-6 h-6 text-white" />
              </div>
              <div className="text-left">
                <p className="font-bold">Same-Day Delivery</p>
                <p className="text-sm text-white/80">Order before 4 PM</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center backdrop-blur-sm">
                <Moon className="w-6 h-6 text-white" />
              </div>
              <div className="text-left">
                <p className="font-bold">Midnight Delivery</p>
                <p className="text-sm text-white/80">For perfect birthday surprises</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
