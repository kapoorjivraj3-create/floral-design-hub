import { Button } from "@/components/ui/button";
import { MessageCircle, PhoneCall } from "lucide-react";

export function HeroSection() {
  return (
    <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
      {/* Background Image with elegant overlay */}
      <div className="absolute inset-0 z-0">
        {/* Unsplash beautiful bright floral arrangement */}
        <img
          src="https://images.unsplash.com/photo-1563241527-3004b7be0ffd?q=80&w=2000&auto=format&fit=crop"
          alt="Beautiful floral arrangement"
          className="w-full h-full object-cover object-center"
        />
        {/* Soft gradient wash to ensure text readability while keeping it light and airy */}
        <div className="absolute inset-0 bg-gradient-to-r from-white/90 via-white/70 to-white/30 md:from-white/80 md:via-white/50 md:to-transparent" />
      </div>

      <div className="container relative z-10 mx-auto px-4 md:px-6 flex flex-col md:block items-center text-center md:text-left mt-20">
        <div className="max-w-2xl animate-in fade-in slide-in-from-bottom-8 duration-1000">
          <span className="inline-block py-1 px-3 rounded-full bg-secondary text-secondary-foreground text-sm font-medium mb-6 shadow-sm border border-white/50">
            Premium Florist in Kolkata
          </span>
          <h1 className="text-5xl md:text-7xl font-display font-bold text-foreground leading-tight mb-6 text-balance">
            Fresh Flowers. <br/>
            <span className="text-primary italic">Beautiful Moments.</span>
          </h1>
          <p className="text-lg md:text-xl text-foreground/80 mb-10 text-balance leading-relaxed max-w-xl mx-auto md:mx-0">
            Express your feelings with our elegant, hand-crafted floral arrangements. Same-day and midnight delivery available across Kolkata.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
            <Button
              asChild
              size="lg"
              className="rounded-full bg-[#25D366] hover:bg-[#20bd5a] text-white shadow-lg shadow-[#25D366]/25 hover:shadow-xl hover:shadow-[#25D366]/40 hover:-translate-y-0.5 transition-all text-base px-8 py-6 h-auto"
            >
              <a href="https://wa.me/919433179549" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="w-5 h-5 mr-2" />
                Order on WhatsApp
              </a>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="rounded-full bg-white/80 backdrop-blur border-2 border-primary text-primary hover:bg-primary hover:text-white shadow-lg shadow-black/5 hover:shadow-xl hover:-translate-y-0.5 transition-all text-base px-8 py-6 h-auto"
            >
              <a href="tel:+919433179549">
                <PhoneCall className="w-5 h-5 mr-2" />
                Call Us Now
              </a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
