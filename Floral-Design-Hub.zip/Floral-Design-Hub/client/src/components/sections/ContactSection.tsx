import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertMessageSchema, type InsertMessage } from "@shared/schema";
import { useSubmitContact } from "@/hooks/use-contact";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { MapPin, Phone, Mail, Loader2, Send } from "lucide-react";

export function ContactSection() {
  const mutation = useSubmitContact();

  const form = useForm<InsertMessage>({
    resolver: zodResolver(insertMessageSchema),
    defaultValues: {
      name: "",
      phone: "",
      message: "",
    },
  });

  function onSubmit(data: InsertMessage) {
    mutation.mutate(data, {
      onSuccess: () => {
        form.reset();
      }
    });
  }

  return (
    <section id="contact" className="py-24 bg-white relative">
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          
          {/* Contact Info & Map */}
          <div>
            <h2 className="text-primary font-medium tracking-wider uppercase text-sm mb-2">Get In Touch</h2>
            <h3 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-6">
              Visit Us or Drop a Message
            </h3>
            <p className="text-foreground/70 mb-10 text-balance">
              We are located near Lakshmi Narayan Hospital. Drop by to pick up fresh flowers or message us for delivery inquiries.
            </p>

            <div className="space-y-6 mb-10 bg-background p-8 rounded-2xl border border-border shadow-sm">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center shrink-0 shadow-sm">
                  <MapPin className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h4 className="font-bold text-foreground">Address</h4>
                  <p className="text-foreground/70 text-sm mt-1">
                    37 A, Justice Chandra Madhab Rd, J. C., Bhowanipore, M. Road,<br/>
                    Kolkata, West Bengal 700020, India<br/>
                    <span className="italic text-foreground/50">(Near Lakshmi Narayan Hospital)</span>
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center shrink-0 shadow-sm">
                  <Phone className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h4 className="font-bold text-foreground">Phone</h4>
                  <p className="text-foreground/70 text-sm mt-1">
                    <a href="tel:+919433179549" className="hover:text-primary transition-colors">+91 94331 79549</a>
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center shrink-0 shadow-sm">
                  <Mail className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h4 className="font-bold text-foreground">Email</h4>
                  <p className="text-foreground/70 text-sm mt-1">
                    <a href="mailto:floralworld2013@gmail.com" className="hover:text-primary transition-colors">floralworld2013@gmail.com</a>
                  </p>
                </div>
              </div>
            </div>

            {/* Simple Map Placeholder (Using iframe for Google Maps) */}
            <div className="w-full h-64 bg-secondary rounded-2xl overflow-hidden shadow-inner relative border border-border">
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3684.9745347201764!2d88.3458!3d22.5426!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjLCsDMyJzMzLjQiTiA4OMKwMjAnNDQuOSJF!5e0!3m2!1sen!2sin!4v1620000000000!5m2!1sen!2sin" 
                width="100%" 
                height="100%" 
                style={{ border: 0 }} 
                allowFullScreen={false} 
                loading="lazy"
                title="Floral World Location"
                className="opacity-90 grayscale-[20%] hover:grayscale-0 transition-all duration-500"
              ></iframe>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-background p-8 md:p-10 rounded-3xl border border-border shadow-xl">
            <h3 className="text-2xl font-display font-bold text-foreground mb-2">Send an Inquiry</h3>
            <p className="text-foreground/60 mb-8 text-sm">Fill out the form below and we'll get back to you regarding your floral needs.</p>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-foreground font-semibold">Your Name</FormLabel>
                      <FormControl>
                        <Input placeholder="John Doe" className="bg-white py-6 rounded-xl border-border/60 focus-visible:ring-primary/20 focus-visible:border-primary" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-foreground font-semibold">Phone Number</FormLabel>
                      <FormControl>
                        <Input placeholder="+91 98765 43210" className="bg-white py-6 rounded-xl border-border/60 focus-visible:ring-primary/20 focus-visible:border-primary" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-foreground font-semibold">Message / Requirements</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="I would like to order a bouquet for..." 
                          className="bg-white min-h-[150px] rounded-xl border-border/60 focus-visible:ring-primary/20 focus-visible:border-primary resize-none" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button 
                  type="submit" 
                  disabled={mutation.isPending}
                  className="w-full py-6 rounded-xl text-lg shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all bg-primary hover:bg-primary/90 text-white"
                >
                  {mutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      Sending...
                    </>
                  ) : (
                    <>
                      <Send className="mr-2 h-5 w-5" />
                      Send Message
                    </>
                  )}
                </Button>
              </form>
            </Form>
          </div>

        </div>
      </div>
    </section>
  );
}
