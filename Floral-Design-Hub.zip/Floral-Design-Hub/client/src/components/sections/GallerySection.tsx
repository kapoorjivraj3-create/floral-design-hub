export function GallerySection() {
  const images = [
    {
      url: "https://images.unsplash.com/photo-1526047932273-341f2a7631f9?q=80&w=800&auto=format&fit=crop",
      alt: "Pink and white bouquet",
      span: "md:col-span-2 md:row-span-2"
    },
    {
      url: "https://images.unsplash.com/photo-1582794543139-8ac9cb0f7b11?q=80&w=800&auto=format&fit=crop",
      alt: "Elegant rose arrangement",
      span: "md:col-span-1 md:row-span-1"
    },
    {
      url: "https://images.unsplash.com/photo-1508610048659-a06b669e3321?q=80&w=800&auto=format&fit=crop",
      alt: "Mixed colorful flowers",
      span: "md:col-span-1 md:row-span-1"
    },
    {
      url: "https://images.unsplash.com/photo-1562690868-60bbe7293e94?q=80&w=800&auto=format&fit=crop",
      alt: "Romantic red roses",
      span: "md:col-span-2 md:row-span-1"
    },
  ];

  return (
    <section id="gallery" className="py-24 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
          <div className="max-w-xl">
            <h2 className="text-primary font-medium tracking-wider uppercase text-sm mb-2">Our Gallery</h2>
            <h3 className="text-3xl md:text-4xl font-display font-bold text-foreground">
              A Glimpse of Our Creations
            </h3>
          </div>
          <p className="text-foreground/70 max-w-md text-balance md:text-right">
            Every bouquet is uniquely crafted. Browse some of our favorite recent floral designs made for happy customers.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 auto-rows-[250px] gap-4">
          {images.map((img, i) => (
            <div 
              key={i} 
              className={`relative group overflow-hidden rounded-2xl ${img.span}`}
            >
              <img 
                src={img.url} 
                alt={img.alt} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
