import { Star } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export function ReviewsSection() {
  const reviews = [
    {
      name: "Priya S.",
      location: "Ballygunge",
      text: "Ordered a birthday bouquet and cake combo for my mother. The flowers were incredibly fresh and the delivery was right on time. Highly recommended!",
    },
    {
      name: "Rahul D.",
      location: "New Town",
      text: "I needed a last-minute anniversary gift and Floral World saved the day. The midnight delivery service was flawless and the roses were stunning.",
    },
    {
      name: "Ananya M.",
      location: "Bhowanipore",
      text: "Their custom arrangements are beautiful. Very reasonable pricing for the premium quality they provide. They are my go-to florist in Kolkata now.",
    }
  ];

  return (
    <section id="reviews" className="py-24 bg-background">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-primary font-medium tracking-wider uppercase text-sm mb-2">Customer Testimonials</h2>
          <h3 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-4">
            Smiles We've Delivered
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {reviews.map((review, i) => (
            <Card key={i} className="bg-white border-border/50 shadow-md hover:shadow-xl transition-shadow duration-300">
              <CardContent className="p-8">
                <div className="flex gap-1 mb-6">
                  {[...Array(5)].map((_, j) => (
                    <Star key={j} className="w-5 h-5 fill-primary text-primary" />
                  ))}
                </div>
                <p className="text-foreground/80 mb-8 italic text-lg leading-relaxed">"{review.text}"</p>
                <div>
                  <p className="font-bold text-foreground text-lg">{review.name}</p>
                  <p className="text-sm text-foreground/50">{review.location}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
