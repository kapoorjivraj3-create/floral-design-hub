import { Flower2, Gift, Heart, HeartHandshake, Leaf, Cake, Candy, Sparkles } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export function ServicesSection() {
  const services = [
    { icon: Flower2, title: "Fresh Flower Bouquets", desc: "Hand-tied premium daily blooms.", price: "From ₹499" },
    { icon: Gift, title: "Birthday Bouquets", desc: "Colorful arrangements to celebrate.", price: "From ₹799" },
    { icon: Heart, title: "Anniversary Flowers", desc: "Elegant roses and romantic setups.", price: "From ₹1,299" },
    { icon: HeartHandshake, title: "Romantic Bouquets", desc: "Express love with stunning florals.", price: "From ₹999" },
    { icon: Leaf, title: "Sympathy Flowers", desc: "Respectful and serene wreaths.", price: "From ₹1,500" },
    { icon: Cake, title: "Flowers + Cake", desc: "The perfect combo for any party.", price: "From ₹1,199" },
    { icon: Candy, title: "Flowers + Chocolates", desc: "Sweeten their day effortlessly.", price: "From ₹899" },
    { icon: Sparkles, title: "Custom Arrangements", desc: "Bespoke designs just for you.", price: "Request Quote" },
  ];

  return (
    <section id="services" className="py-24 bg-background">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-primary font-medium tracking-wider uppercase text-sm mb-2">Our Services</h2>
          <h3 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-4">
            Perfect Arrangements For Every Occasion
          </h3>
          <p className="text-foreground/70">
            Whether you are celebrating a milestone or just want to make someone smile, we have the perfect floral gift.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <Card 
              key={index} 
              className="group border-border bg-white shadow-sm hover:shadow-xl hover:border-primary/20 transition-all duration-300 hover:-translate-y-1 overflow-hidden"
            >
              <CardContent className="p-8 text-center flex flex-col h-full">
                <div className="w-16 h-16 mx-auto rounded-2xl bg-secondary/50 flex items-center justify-center mb-6 group-hover:bg-primary group-hover:scale-110 transition-all duration-300">
                  <service.icon className="w-8 h-8 text-primary group-hover:text-white transition-colors" />
                </div>
                <h4 className="text-lg font-bold text-foreground mb-2 group-hover:text-primary transition-colors">{service.title}</h4>
                <p className="text-sm text-foreground/70 mb-4 flex-grow">{service.desc}</p>
                <div className="mt-auto pt-4 border-t border-border/50">
                  <span className="text-primary font-bold">{service.price}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
