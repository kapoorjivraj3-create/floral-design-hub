import { MapPin, Phone, Mail, Instagram, Facebook, Twitter } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-secondary/30 pt-16 pb-8 border-t border-secondary">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          {/* Brand */}
          <div className="space-y-4">
            <h3 className="text-2xl font-display font-bold text-primary">Floral World</h3>
            <p className="text-foreground/70 text-balance leading-relaxed">
              Fresh flowers and beautiful moments delivered across Kolkata. Let us help you express your feelings through our elegant arrangements.
            </p>
            <div className="flex gap-4 pt-2">
              <a href="#" className="w-10 h-10 rounded-full bg-white flex items-center justify-center text-primary hover:bg-primary hover:text-white transition-all shadow-sm">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white flex items-center justify-center text-primary hover:bg-primary hover:text-white transition-all shadow-sm">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white flex items-center justify-center text-primary hover:bg-primary hover:text-white transition-all shadow-sm">
                <Twitter className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Contact */}
          <div className="space-y-4">
            <h4 className="text-lg font-display font-semibold text-foreground">Contact Us</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-3 text-foreground/70">
                <MapPin className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                <span>37 A, Justice Chandra Madhab Rd, J. C., Bhowanipore, M. Road, Kolkata, West Bengal 700020</span>
              </li>
              <li className="flex items-center gap-3 text-foreground/70">
                <Phone className="w-5 h-5 text-primary shrink-0" />
                <a href="tel:+919433179549" className="hover:text-primary transition-colors">+91 94331 79549</a>
              </li>
              <li className="flex items-center gap-3 text-foreground/70">
                <Mail className="w-5 h-5 text-primary shrink-0" />
                <a href="mailto:floralworld2013@gmail.com" className="hover:text-primary transition-colors">floralworld2013@gmail.com</a>
              </li>
            </ul>
          </div>

          {/* Hours & Info */}
          <div className="space-y-4">
            <h4 className="text-lg font-display font-semibold text-foreground">Business Hours</h4>
            <ul className="space-y-2 text-foreground/70">
              <li className="flex justify-between border-b border-border/50 pb-2">
                <span>Monday - Sunday</span>
                <span className="font-medium">7:00 AM – 10:00 PM</span>
              </li>
            </ul>
            <div className="pt-4">
              <p className="text-sm text-foreground/60 mb-1">Proprietor: Nitin Gharwra</p>
              <p className="text-sm text-foreground/60">Service Areas: Kolkata, Kasba, Joka, Dumdum, Rajarhat, New Town, Ballygunge, Garia</p>
            </div>
          </div>
        </div>

        {/* SEO Hidden text for better ranking without cluttering UI */}
        <div className="sr-only">
          Best florist in Kolkata. Flower delivery in Bhowanipore. Same day flower delivery Kolkata. Midnight flower delivery Kolkata. Buy fresh flowers online.
        </div>

        <div className="text-center pt-8 border-t border-border/50 text-foreground/50 text-sm">
          <p>&copy; {new Date().getFullYear()} Floral World. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
