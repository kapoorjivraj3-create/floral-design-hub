## Packages
react-hook-form | Form state management
@hookform/resolvers | Zod validation resolver for forms
lucide-react | Beautiful icons
framer-motion | Smooth scroll and entry animations

## Notes
Static images are sourced from Unsplash.
The contact form uses the provided `/api/contact` endpoint.
