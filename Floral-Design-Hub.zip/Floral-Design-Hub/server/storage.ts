import { db } from "./db";
import {
  contactMessages,
  type InsertMessage,
  type Message
} from "@shared/schema";

export interface IStorage {
  createContactMessage(message: InsertMessage): Promise<Message>;
  getContactMessages(): Promise<Message[]>;
}

export class DatabaseStorage implements IStorage {
  async createContactMessage(message: InsertMessage): Promise<Message> {
    const [newMessage] = await db.insert(contactMessages).values(message).returning();
    return newMessage;
  }
  
  async getContactMessages(): Promise<Message[]> {
    return await db.select().from(contactMessages);
  }
}

export const storage = new DatabaseStorage();
